png or jpg files are supported, ideal is not bigger than around 800 x 600
